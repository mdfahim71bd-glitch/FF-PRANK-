package com.ff.funnyvoice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import java.io.File
import java.util.Collections

class AudioManagerFF(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val activePlayers = Collections.synchronizedSet(mutableSetOf<MediaPlayer>())

    var masterVolume: Float
        get() = prefs.getFloat(KEY_VOLUME, 1.0f)
        set(value) {
            val clamped = value.coerceIn(0.0f, 1.0f)
            prefs.edit().putFloat(KEY_VOLUME, clamped).apply()
            synchronized(activePlayers) {
                for (player in activePlayers) {
                    try {
                        player.setVolume(clamped, clamped)
                    } catch (_: Exception) {}
                }
            }
        }

    companion object {
        private const val TAG = "AudioManagerFF"
        private const val PREFS_NAME = "ff_audio_settings"
        private const val KEY_VOLUME = "master_volume"
    }

    fun triggerHaptic(durationMs: Long = 35) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val effect = VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                vibratorManager?.vibrate(CombinedVibration.createParallel(effect))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Haptic vibration failed: ${e.message}")
        }
    }

    @Synchronized
    fun playVoice(
        item: VoiceItem,
        onStarted: (() -> Unit)? = null,
        onCompleted: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean {
        triggerHaptic()

        val player = MediaPlayer()
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .setUsage(AudioAttributes.USAGE_GAME)
            .build()

        player.setAudioAttributes(audioAttributes)
        val currentVol = masterVolume
        player.setVolume(currentVol, currentVol)

        var dataSourceSuccess = false

        if (!item.filePath.isNullOrBlank()) {
            val localFile = File(item.filePath)
            if (localFile.exists() && localFile.canRead()) {
                try {
                    player.setDataSource(localFile.absolutePath)
                    dataSourceSuccess = true
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to load from local file: ${item.filePath}, fallback to URI", e)
                }
            }
        }

        if (!dataSourceSuccess) {
            try {
                val uri = Uri.parse(item.uriString)
                player.setDataSource(context, uri)
                dataSourceSuccess = true
            } catch (e: Exception) {
                Log.e(TAG, "Failed to set data source from URI: ${item.uriString}", e)
                player.release()
                onError?.invoke("Audio source unavailable: ${e.localizedMessage ?: "Unknown error"}")
                return false
            }
        }

        try {
            player.setOnPreparedListener { mp ->
                try {
                    mp.start()
                    activePlayers.add(mp)
                    onStarted?.invoke()
                } catch (e: Exception) {
                    Log.e(TAG, "Error starting MediaPlayer", e)
                    safeReleasePlayer(mp)
                    onError?.invoke("Playback start failed")
                }
            }

            player.setOnCompletionListener { mp ->
                safeReleasePlayer(mp)
                onCompleted?.invoke()
            }

            player.setOnErrorListener { mp, what, extra ->
                Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
                safeReleasePlayer(mp)
                onError?.invoke("Playback error ($what, $extra)")
                true
            }

            player.prepareAsync()
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error preparing player", e)
            safeReleasePlayer(player)
            onError?.invoke("Prepare error: ${e.message}")
            return false
        }
    }

    @Synchronized
    fun stopAll() {
        triggerHaptic(50)
        synchronized(activePlayers) {
            for (player in activePlayers) {
                try {
                    if (player.isPlaying) {
                        player.stop()
                    }
                    player.reset()
                    player.release()
                } catch (e: Exception) {
                    Log.w(TAG, "Error stopping player", e)
                }
            }
            activePlayers.clear()
        }
    }

    fun releaseAll() {
        stopAll()
    }

    private fun safeReleasePlayer(player: MediaPlayer) {
        activePlayers.remove(player)
        try {
            player.reset()
            player.release()
        } catch (_: Exception) {}
    }
}
