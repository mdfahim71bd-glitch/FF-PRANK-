package com.ff.funnyvoice

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class VoiceItem(
    val id: String,
    val name: String,
    val uriString: String,
    val filePath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("uriString", uriString)
            put("filePath", filePath ?: "")
            put("createdAt", createdAt)
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): VoiceItem {
            val filePath = obj.optString("filePath")
            return VoiceItem(
                id = obj.getString("id"),
                name = obj.getString("name"),
                uriString = obj.getString("uriString"),
                filePath = if (filePath.isNullOrBlank()) null else filePath,
                createdAt = obj.optLong("createdAt", System.currentTimeMillis())
            )
        }
    }
}

class VoiceStore(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "VoiceStore"
        private const val PREFS_NAME = "ff_funny_voice_store"
        private const val KEY_VOICES_JSON = "custom_voices_list"
        private const val VOICES_DIR_NAME = "custom_voices"
    }

    @Synchronized
    fun getVoices(): List<VoiceItem> {
        val jsonString = prefs.getString(KEY_VOICES_JSON, null) ?: return emptyList()
        val list = mutableListOf<VoiceItem>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(VoiceItem.fromJsonObject(obj))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing saved voices JSON", e)
        }
        return list
    }

    @Synchronized
    fun addVoice(name: String, sourceUri: Uri, resolver: ContentResolver): VoiceItem? {
        val id = UUID.randomUUID().toString()
        val safeName = if (name.isBlank()) "Voice ${getVoices().size + 1}" else name.trim()

        try {
            resolver.takePersistableUriPermission(
                sourceUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (se: SecurityException) {
            Log.w(TAG, "Could not take persistable permission for $sourceUri: ${se.message}")
        } catch (e: Exception) {
            Log.w(TAG, "General exception taking persistable permission: ${e.message}")
        }

        var localFilePath: String? = null
        try {
            val dir = File(context.filesDir, VOICES_DIR_NAME)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            val destinationFile = File(dir, "voice_$id.audio")

            resolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    input.copyTo(output)
                }
            }
            if (destinationFile.exists() && destinationFile.length() > 0) {
                localFilePath = destinationFile.absolutePath
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy audio stream to internal storage", e)
        }

        val newItem = VoiceItem(
            id = id,
            name = safeName,
            uriString = sourceUri.toString(),
            filePath = localFilePath,
            createdAt = System.currentTimeMillis()
        )

        val currentList = getVoices().toMutableList()
        currentList.add(newItem)
        saveList(currentList)
        return newItem
    }

    @Synchronized
    fun renameVoice(id: String, newName: String): Boolean {
        if (newName.isBlank()) return false
        val currentList = getVoices().toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        if (index != -1) {
            val item = currentList[index]
            currentList[index] = item.copy(name = newName.trim())
            saveList(currentList)
            return true
        }
        return false
    }

    @Synchronized
    fun deleteVoice(id: String): Boolean {
        val currentList = getVoices().toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        if (index != -1) {
            val item = currentList[index]
            item.filePath?.let { path ->
                try {
                    val file = File(path)
                    if (file.exists()) {
                        file.delete()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Could not delete local audio file: $path", e)
                }
            }
            currentList.removeAt(index)
            saveList(currentList)
            return true
        }
        return false
    }

    @Synchronized
    fun clearAll() {
        val currentList = getVoices()
        for (item in currentList) {
            item.filePath?.let { path ->
                try {
                    File(path).delete()
                } catch (_: Exception) {}
            }
        }
        prefs.edit().remove(KEY_VOICES_JSON).apply()
    }

    private fun saveList(list: List<VoiceItem>) {
        val jsonArray = JSONArray()
        for (item in list) {
            jsonArray.put(item.toJsonObject())
        }
        prefs.edit().putString(KEY_VOICES_JSON, jsonArray.toString()).apply()
    }
}
