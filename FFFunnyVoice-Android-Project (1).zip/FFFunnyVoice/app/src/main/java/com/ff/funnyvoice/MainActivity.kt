package com.ff.funnyvoice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Main Activity for FF Funny Voice.
 * Provides the gaming dashboard, custom audio manager, master volume,
 * and overlay permission / floating service controls.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var voiceStore: VoiceStore
    private lateinit var audioManager: AudioManagerFF

    private lateinit var overlayStatusText: TextView
    private lateinit var overlayActionBtn: TextView
    private lateinit var startFloatingBtn: TextView
    private lateinit var stopFloatingBtn: TextView
    private lateinit var volumePercentText: TextView
    private lateinit var volumeSeekBar: SeekBar
    private lateinit var voiceCountBadge: TextView
    private lateinit var voiceListContainer: LinearLayout
    private lateinit var emptyVoicesView: TextView

    // Currently playing voice ID for UI indication
    private var activePlayingId: String? = null

    // Audio file picker launcher (Intent.ACTION_OPEN_DOCUMENT for persistable URI)
    private val pickAudioLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            promptVoiceNameAndSave(uri)
        }
    }

    // Android 13+ Notification Permission Launcher
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        proceedStartFloatingService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        voiceStore = VoiceStore(this)
        audioManager = AudioManagerFF(this)

        setContentView(buildMainUI())
    }

    override fun onResume() {
        super.onResume()
        updatePermissionAndServiceStatus()
        refreshVoiceList()
    }

    override fun onDestroy() {
        super.onDestroy()
        audioManager.releaseAll()
    }

    private fun buildMainUI(): View {
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0E14"))
            setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
        }

        // Header Section
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dpToPx(8), 0, dpToPx(16))
        }

        val appTitle = TextView(this).apply {
            text = "⚡ FF FUNNY VOICE"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
            gravity = Gravity.CENTER
        }

        val appSubtitle = TextView(this).apply {
            text = "GAMING SOUNDBOARD"
            textSize = 12f
            letterSpacing = 0.2f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#8B949E"))
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(2), 0, 0)
        }

        header.addView(appTitle)
        header.addView(appSubtitle)
        rootLayout.addView(header)

        // Scrollable Content
        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
            isFillViewport = true
        }

        val contentLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scrollView.addView(contentLayout)
        rootLayout.addView(scrollView)

        // 1. Overlay Permission Card
        val permCard = createOverlayCard()
        contentLayout.addView(permCard)

        // 2. Service Controls (START / STOP FLOATING)
        val serviceControls = createServiceControls()
        contentLayout.addView(serviceControls)

        // 3. Master Volume & STOP ALL Card
        val volumeCard = createVolumeAndStopAllCard()
        contentLayout.addView(volumeCard)

        // 4. MY VOICES Section Header
        val voicesHeader = createVoicesHeader()
        contentLayout.addView(voicesHeader)

        // 5. Dynamic Voices Container
        voiceListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        contentLayout.addView(voiceListContainer)

        // Empty state view
        emptyVoicesView = TextView(this).apply {
            text = "No custom voices added yet!\nTap '+ ADD MY VOICE' below to pick any audio from your phone."
            textSize = 13f
            setTextColor(Color.parseColor("#8B949E"))
            gravity = Gravity.CENTER
            setPadding(dpToPx(16), dpToPx(36), dpToPx(16), dpToPx(36))
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10f).toFloat()
                setColor(Color.parseColor("#12161F"))
                setStroke(dpToPx(1f), Color.parseColor("#21262D"))
            }
            background = bg
        }
        contentLayout.addView(emptyVoicesView)

        // 6. ADD MY VOICE Button (Bottom Sticky Bar)
        val addVoiceBtn = TextView(this).apply {
            text = "➕ ADD MY VOICE"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#0B0E14"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10f).toFloat()
                setColor(Color.parseColor("#00E5FF"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(48)
            ).apply {
                topMargin = dpToPx(12)
            }
            setOnClickListener {
                audioManager.triggerHaptic(20)
                openAudioPicker()
            }
        }
        rootLayout.addView(addVoiceBtn)

        return rootLayout
    }

    private fun createOverlayCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10f).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dpToPx(1f), Color.parseColor("#30363D"))
            }
            background = bg
            setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(12)
            }
        }

        val textLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
        }

        val title = TextView(this).apply {
            text = "FLOATING OVERLAY"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }

        overlayStatusText = TextView(this).apply {
            text = "Checking permission..."
            textSize = 12f
            setTextColor(Color.parseColor("#8B949E"))
        }

        textLayout.addView(title)
        textLayout.addView(overlayStatusText)
        card.addView(textLayout)

        overlayActionBtn = TextView(this).apply {
            text = "GRANT"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(6f).toFloat()
                setColor(Color.parseColor("#1F2937"))
                setStroke(dpToPx(1f), Color.parseColor("#00E5FF"))
            }
            background = bg
            setPadding(dpToPx(12), dpToPx(6), dpToPx(12), dpToPx(6))
            setOnClickListener {
                audioManager.triggerHaptic(20)
                requestOverlayPermission()
            }
        }
        card.addView(overlayActionBtn)

        return card
    }

    private fun createServiceControls(): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(12)
            }
        }

        startFloatingBtn = TextView(this).apply {
            text = "▶ START BUBBLE"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#0B0E14"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10f).toFloat()
                setColor(Color.parseColor("#00E5FF"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(46), 1.3f).apply {
                marginEnd = dpToPx(8)
            }
            setOnClickListener {
                audioManager.triggerHaptic(25)
                startFloatingServiceFlow()
            }
        }

        stopFloatingBtn = TextView(this).apply {
            text = "⏹ STOP"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#F0F6FC"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10f).toFloat()
                setColor(Color.parseColor("#21262D"))
                setStroke(dpToPx(1f), Color.parseColor("#30363D"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(46), 0.8f)
            setOnClickListener {
                audioManager.triggerHaptic(25)
                stopFloatingService()
            }
        }

        container.addView(startFloatingBtn)
        container.addView(stopFloatingBtn)
        return container
    }

    private fun createVolumeAndStopAllCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10f).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(dpToPx(1f), Color.parseColor("#30363D"))
            }
            background = bg
            setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val volLabel = TextView(this).apply {
            text = "MASTER VOLUME"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#8B949E"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
        }

        val currentVolPct = (audioManager.masterVolume * 100).toInt()
        volumePercentText = TextView(this).apply {
            text = "$currentVolPct%"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
        }

        topRow.addView(volLabel)
        topRow.addView(volumePercentText)
        card.addView(topRow)

        volumeSeekBar = SeekBar(this).apply {
            max = 100
            progress = currentVolPct
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(6)
                bottomMargin = dpToPx(8)
            }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val vol = progress / 100.0f
                        audioManager.masterVolume = vol
                        volumePercentText.text = "$progress%"
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        card.addView(volumeSeekBar)

        val stopAllBtn = TextView(this).apply {
            text = "⏹ STOP ALL SOUNDS"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8f).toFloat()
                setColor(Color.parseColor("#FF2A55"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(40)
            )
            setOnClickListener {
                audioManager.stopAll()
                activePlayingId = null
                refreshVoiceList()
                Toast.makeText(this@MainActivity, "All sounds stopped", Toast.LENGTH_SHORT).show()
            }
        }
        card.addView(stopAllBtn)

        return card
    }

    private fun createVoicesHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(10))
        }

        val title = TextView(this).apply {
            text = "MY VOICES"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
        }

        voiceCountBadge = TextView(this).apply {
            text = "0"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(12f).toFloat()
                setColor(Color.parseColor("#162330"))
                setStroke(dpToPx(1f), Color.parseColor("#00E5FF"))
            }
            background = bg
            setPadding(dpToPx(10), dpToPx(3), dpToPx(10), dpToPx(3))
        }

        row.addView(title)
        row.addView(voiceCountBadge)
        return row
    }

    private fun refreshVoiceList() {
        voiceListContainer.removeAllViews()
        val list = voiceStore.getVoices()
        voiceCountBadge.text = "${list.size}"

        if (list.isEmpty()) {
            emptyVoicesView.visibility = View.VISIBLE
            return
        } else {
            emptyVoicesView.visibility = View.GONE
        }

        for (item in list) {
            val card = createVoiceCard(item)
            voiceListContainer.addView(card)
        }
    }

    private fun createVoiceCard(item: VoiceItem): View {
        val isCurrentlyPlaying = (item.id == activePlayingId)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10f).toFloat()
                setColor(Color.parseColor("#161B22"))
                setStroke(
                    dpToPx(1f),
                    if (isCurrentlyPlaying) Color.parseColor("#00E5FF") else Color.parseColor("#21262D")
                )
            }
            background = bg
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
        }

        val playBtn = TextView(this).apply {
            text = if (isCurrentlyPlaying) "🔊" else "▶"
            textSize = 16f
            setTextColor(Color.parseColor("#00E5FF"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(6f).toFloat()
                setColor(Color.parseColor("#1B222D"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(36)).apply {
                marginEnd = dpToPx(10)
            }
            setOnClickListener {
                if (isCurrentlyPlaying) {
                    audioManager.stopAll()
                    activePlayingId = null
                    refreshVoiceList()
                } else {
                    activePlayingId = item.id
                    refreshVoiceList()
                    audioManager.playVoice(
                        item,
                        onStarted = {},
                        onCompleted = {
                            runOnUiThread {
                                if (activePlayingId == item.id) {
                                    activePlayingId = null
                                    refreshVoiceList()
                                }
                            }
                        },
                        onError = { error ->
                            runOnUiThread {
                                activePlayingId = null
                                refreshVoiceList()
                                Toast.makeText(this@MainActivity, error, Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }
        card.addView(playBtn)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
        }

        val nameView = TextView(this).apply {
            text = item.name
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#F0F6FC"))
        }

        val statusView = TextView(this).apply {
            text = if (isCurrentlyPlaying) "Playing..." else "Ready"
            textSize = 11f
            setTextColor(if (isCurrentlyPlaying) Color.parseColor("#00E5FF") else Color.parseColor("#8B949E"))
        }

        textCol.addView(nameView)
        textCol.addView(statusView)
        card.addView(textCol)

        val renameBtn = TextView(this).apply {
            text = "✏"
            textSize = 14f
            setTextColor(Color.parseColor("#8B949E"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dpToPx(34), dpToPx(34)).apply {
                marginEnd = dpToPx(4)
            }
            setOnClickListener {
                audioManager.triggerHaptic(20)
                promptRename(item)
            }
        }
        card.addView(renameBtn)

        val deleteBtn = TextView(this).apply {
            text = "🗑"
            textSize = 14f
            setTextColor(Color.parseColor("#FF4757"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dpToPx(34), dpToPx(34))
            setOnClickListener {
                audioManager.triggerHaptic(20)
                confirmDelete(item)
            }
        }
        card.addView(deleteBtn)

        return card
    }

    private fun openAudioPicker() {
        try {
            pickAudioLauncher.launch(arrayOf("audio/*"))
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to launch file picker: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun promptVoiceNameAndSave(uri: Uri) {
        val input = EditText(this).apply {
            hint = "e.g. Free Fire Headshot / Laugh"
            setHintTextColor(Color.parseColor("#8B949E"))
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1F242D"))
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
        }

        val container = FrameLayout(this).apply {
            setPadding(dpToPx(20), dpToPx(10), dpToPx(20), dpToPx(10))
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("Name Your Voice")
            .setMessage("Give this custom voice a recognizable title:")
            .setView(container)
            .setPositiveButton("SAVE") { _, _ ->
                val name = input.text.toString().trim()
                val added = voiceStore.addVoice(name, uri, contentResolver)
                if (added != null) {
                    Toast.makeText(this, "Voice added successfully!", Toast.LENGTH_SHORT).show()
                    refreshVoiceList()
                    notifyServiceReload()
                } else {
                    Toast.makeText(this, "Failed to save voice audio.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun promptRename(item: VoiceItem) {
        val input = EditText(this).apply {
            setText(item.name)
            setSelection(item.name.length)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1F242D"))
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
        }

        val container = FrameLayout(this).apply {
            setPadding(dpToPx(20), dpToPx(10), dpToPx(20), dpToPx(10))
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("Rename Voice")
            .setView(container)
            .setPositiveButton("UPDATE") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotBlank()) {
                    voiceStore.renameVoice(item.id, newName)
                    refreshVoiceList()
                    notifyServiceReload()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun confirmDelete(item: VoiceItem) {
        AlertDialog.Builder(this)
            .setTitle("Delete Voice")
            .setMessage("Are you sure you want to delete '${item.name}'?")
            .setPositiveButton("DELETE") { _, _ ->
                if (activePlayingId == item.id) {
                    audioManager.stopAll()
                    activePlayingId = null
                }
                voiceStore.deleteVoice(item.id)
                refreshVoiceList()
                notifyServiceReload()
                Toast.makeText(this, "Voice deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun notifyServiceReload() {
        if (FloatingSoundService.isRunning) {
            val reloadIntent = Intent(this, FloatingSoundService::class.java).apply {
                action = FloatingSoundService.ACTION_RELOAD
            }
            startService(reloadIntent)
        }
    }

    private fun updatePermissionAndServiceStatus() {
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        if (hasOverlay) {
            overlayStatusText.text = "Permission Granted ✓"
            overlayStatusText.setTextColor(Color.parseColor("#00E676"))
            overlayActionBtn.visibility = View.GONE
        } else {
            overlayStatusText.text = "Overlay permission required"
            overlayStatusText.setTextColor(Color.parseColor("#FF5252"))
            overlayActionBtn.visibility = View.VISIBLE
        }

        if (FloatingSoundService.isRunning) {
            startFloatingBtn.alpha = 0.5f
            stopFloatingBtn.alpha = 1.0f
        } else {
            startFloatingBtn.alpha = 1.0f
            stopFloatingBtn.alpha = 0.5f
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            try {
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Could not open overlay settings: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startFloatingServiceFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Floating Overlay permission first!", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        proceedStartFloatingService()
    }

    private fun proceedStartFloatingService() {
        val serviceIntent = Intent(this, FloatingSoundService::class.java).apply {
            action = FloatingSoundService.ACTION_START
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Floating bubble started! You can now launch Free Fire.", Toast.LENGTH_LONG).show()
            updatePermissionAndServiceStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to start floating service: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopFloatingService() {
        val serviceIntent = Intent(this, FloatingSoundService::class.java).apply {
            action = FloatingSoundService.ACTION_STOP
        }
        startService(serviceIntent)
        Toast.makeText(this, "Floating bubble stopped", Toast.LENGTH_SHORT).show()
        updatePermissionAndServiceStatus()
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
