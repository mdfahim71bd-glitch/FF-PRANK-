package com.ff.funnyvoice

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.hypot

/**
 * Foreground Service that creates and manages the draggable floating bubble
 * and floating soundboard overlay for in-game use.
 * Compliant with Android 14/15 foreground service media playback requirements.
 */
class FloatingSoundService : Service() {

    companion object {
        private const val TAG = "FloatingSoundService"
        const val CHANNEL_ID = "ff_soundboard_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.ff.funnyvoice.ACTION_START"
        const val ACTION_STOP = "com.ff.funnyvoice.ACTION_STOP"
        const val ACTION_RELOAD = "com.ff.funnyvoice.ACTION_RELOAD"

        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private var windowManager: WindowManager? = null
    private var bubbleView: View? = null
    private var soundboardView: View? = null

    private lateinit var voiceStore: VoiceStore
    private lateinit var audioManager: AudioManagerFF

    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var soundboardParams: WindowManager.LayoutParams

    private var screenWidth = 1080
    private var screenHeight = 1920
    private var touchSlop = 16

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        voiceStore = VoiceStore(this)
        audioManager = AudioManagerFF(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager

        updateScreenDimensions()
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        createNotificationChannel()
        startServiceForeground()

        if (checkOverlayPermission()) {
            initFloatingViews()
        } else {
            Log.e(TAG, "Overlay permission not granted. Stopping service.")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                reloadSoundboardVoiceList()
            }
        }
        return START_STICKY
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun updateScreenDimensions() {
        windowManager?.let { wm ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val windowMetrics = wm.currentWindowMetrics
                val bounds = windowMetrics.bounds
                screenWidth = bounds.width()
                screenHeight = bounds.height()
            } else {
                @Suppress("DEPRECATION")
                val display = wm.defaultDisplay
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                display.getMetrics(metrics)
                screenWidth = metrics.widthPixels
                screenHeight = metrics.heightPixels
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.channel_name)
            val descriptionText = getString(R.string.channel_description)
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun startServiceForeground() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingSoundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.service_running_title))
            .setContentText(getString(R.string.service_running_desc))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openAppPendingIntent)
            .addAction(0, "STOP BUBBLE", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initFloatingViews() {
        val wm = windowManager ?: return

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val bubbleSizeDp = 60
        val bubbleSizePx = dpToPx(bubbleSizeDp)

        bubbleParams = WindowManager.LayoutParams(
            bubbleSizePx,
            bubbleSizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = screenHeight / 3
        }

        bubbleView = createBubbleView()

        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var touchStartTime = 0L

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                if (event == null) return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = bubbleParams.x
                        initialY = bubbleParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        touchStartTime = System.currentTimeMillis()
                        v?.animate()?.scaleX(1.1f)?.scaleY(1.1f)?.setDuration(100)?.start()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()

                        bubbleParams.x = (initialX + dx).coerceIn(0, (screenWidth - bubbleSizePx).coerceAtLeast(0))
                        bubbleParams.y = (initialY + dy).coerceIn(40, (screenHeight - bubbleSizePx - 80).coerceAtLeast(0))

                        try {
                            wm.updateViewLayout(bubbleView, bubbleParams)
                        } catch (e: Exception) {
                            Log.w(TAG, "Error updating bubble layout", e)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        v?.animate()?.scaleX(1.0f)?.scaleY(1.0f)?.setDuration(100)?.start()
                        val totalDx = event.rawX - initialTouchX
                        val totalDy = event.rawY - initialTouchY
                        val distance = hypot(totalDx.toDouble(), totalDy.toDouble())
                        val duration = System.currentTimeMillis() - touchStartTime

                        if (distance < touchSlop && duration < 350) {
                            audioManager.triggerHaptic(25)
                            showSoundboard()
                        }
                        return true
                    }
                }
                return false
            }
        })

        try {
            wm.addView(bubbleView, bubbleParams)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add bubbleView to WindowManager", e)
        }
    }

    private fun createBubbleView(): View {
        val root = FrameLayout(this)

        val bgDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#121820"))
            setStroke(dpToPx(2.5f), Color.parseColor("#00E5FF"))
        }
        root.background = bgDrawable
        root.elevation = dpToPx(8f).toFloat()

        val textIcon = TextView(this).apply {
            text = "⚡"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#00E5FF"))
        }

        val params = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ).apply {
            gravity = Gravity.CENTER
        }
        root.addView(textIcon, params)

        return root
    }

    private fun showSoundboard() {
        val wm = windowManager ?: return

        bubbleView?.visibility = View.GONE

        if (soundboardView != null) {
            reloadSoundboardVoiceList()
            soundboardView?.visibility = View.VISIBLE
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val panelWidth = (screenWidth * 0.90f).toInt().coerceAtMost(dpToPx(380))
        val panelHeight = (screenHeight * 0.65f).toInt().coerceAtMost(dpToPx(520))

        soundboardParams = WindowManager.LayoutParams(
            panelWidth,
            panelHeight,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        soundboardView = createSoundboardView()

        try {
            wm.addView(soundboardView, soundboardParams)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add soundboardView to WindowManager", e)
            bubbleView?.visibility = View.VISIBLE
        }
    }

    private fun hideSoundboard() {
        soundboardView?.visibility = View.GONE
        bubbleView?.visibility = View.VISIBLE
    }

    private fun createSoundboardView(): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(16f).toFloat()
                setColor(Color.parseColor("#12161F"))
                setStroke(dpToPx(2f), Color.parseColor("#00E5FF"))
            }
            background = bg
            setPadding(dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14))
            elevation = dpToPx(12f).toFloat()
        }

        // Top Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(10))
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
        }

        val title = TextView(this).apply {
            text = "FF FUNNY VOICE"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
        }

        val subtitle = TextView(this).apply {
            text = "MY VOICES"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#8B949E"))
        }
        titleCol.addView(title)
        titleCol.addView(subtitle)

        val minimizeBtn = TextView(this).apply {
            text = "🗕 MIN"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(6f).toFloat()
                setColor(Color.parseColor("#1C2430"))
                setStroke(dpToPx(1f), Color.parseColor("#00E5FF"))
            }
            background = bg
            setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6))
            setOnClickListener {
                audioManager.triggerHaptic(20)
                hideSoundboard()
            }
        }

        header.addView(titleCol)
        header.addView(minimizeBtn)
        container.addView(header)

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
            isFillViewport = true
        }

        val voiceListLayout = LinearLayout(this).apply {
            tag = "voice_list_container"
            orientation = LinearLayout.VERTICAL
        }
        scrollView.addView(voiceListLayout)
        container.addView(scrollView)

        populateVoicesIntoLayout(voiceListLayout)

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(10), 0, 0)
        }

        val stopAllBtn = TextView(this).apply {
            text = "⏹ STOP ALL"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8f).toFloat()
                setColor(Color.parseColor("#FF2A55"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(38), 1.2f).apply {
                marginEnd = dpToPx(6)
            }
            setOnClickListener {
                audioManager.stopAll()
                Toast.makeText(context, "All sounds stopped", Toast.LENGTH_SHORT).show()
            }
        }

        val openAppBtn = TextView(this).apply {
            text = "➕ ADD"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#0B0E14"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8f).toFloat()
                setColor(Color.parseColor("#00E5FF"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(38), 1.0f).apply {
                marginEnd = dpToPx(6)
            }
            setOnClickListener {
                audioManager.triggerHaptic(20)
                hideSoundboard()
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
            }
        }

        val closeBtn = TextView(this).apply {
            text = "✕"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#8B949E"))
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8f).toFloat()
                setColor(Color.parseColor("#21262D"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(38), dpToPx(38))
            setOnClickListener {
                audioManager.triggerHaptic(25)
                stopSelf()
            }
        }

        bottomBar.addView(stopAllBtn)
        bottomBar.addView(openAppBtn)
        bottomBar.addView(closeBtn)
        container.addView(bottomBar)

        return container
    }

    private fun populateVoicesIntoLayout(layout: LinearLayout) {
        layout.removeAllViews()
        val voices = voiceStore.getVoices()

        if (voices.isEmpty()) {
            val emptyMsg = TextView(this).apply {
                text = "No custom voices added yet!\nTap '+ ADD' to pick audio from your phone."
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#8B949E"))
                setPadding(dpToPx(16), dpToPx(32), dpToPx(16), dpToPx(32))
            }
            layout.addView(emptyMsg)
            return
        }

        for (item in voices) {
            val voiceBtn = createVoiceButton(item)
            layout.addView(voiceBtn)
        }
    }

    private fun createVoiceButton(item: VoiceItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8f).toFloat()
                setColor(Color.parseColor("#1B222D"))
                setStroke(dpToPx(1f), Color.parseColor("#2E3846"))
            }
            background = bg
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
        }

        val playIcon = TextView(this).apply {
            text = "▶"
            textSize = 16f
            setTextColor(Color.parseColor("#00E5FF"))
            setPadding(0, 0, dpToPx(10), 0)
        }

        val nameText = TextView(this).apply {
            text = item.name
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#F0F6FC"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
        }

        row.addView(playIcon)
        row.addView(nameText)

        row.setOnClickListener {
            playIcon.text = "🔊"
            audioManager.playVoice(
                item,
                onStarted = {
                    playIcon.post { playIcon.text = "🔊" }
                },
                onCompleted = {
                    playIcon.post { playIcon.text = "▶" }
                },
                onError = { error ->
                    playIcon.post {
                        playIcon.text = "⚠"
                        Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        return row
    }

    private fun reloadSoundboardVoiceList() {
        val root = soundboardView as? LinearLayout ?: return
        val listContainer = root.findViewWithTag<LinearLayout>("voice_list_container") ?: return
        populateVoicesIntoLayout(listContainer)
    }

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            resources.displayMetrics
        ).toInt()
    }

    private fun dpToPx(dp: Int): Int = dpToPx(dp.toFloat())

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        audioManager.releaseAll()

        safeRemoveView(bubbleView)
        safeRemoveView(soundboardView)
        bubbleView = null
        soundboardView = null
    }

    private fun safeRemoveView(view: View?) {
        if (view != null && windowManager != null) {
            try {
                if (view.isAttachedToWindow) {
                    windowManager?.removeViewImmediate(view)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error removing view from WindowManager", e)
            }
        }
    }
}
